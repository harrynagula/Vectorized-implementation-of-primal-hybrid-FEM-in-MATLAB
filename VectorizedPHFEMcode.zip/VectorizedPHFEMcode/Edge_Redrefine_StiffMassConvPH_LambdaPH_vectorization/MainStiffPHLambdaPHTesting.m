%    MainStiffPHLambdaPHTesting.m is calculates the runtimes listed in 
%    Table 3 for StiffMassConv_PH.m and Lambda_PH.m.

%    Remark: This program is a supplement to the paper 
%    "Vectorized implementation of primal hybrid FEM in MATLAB" 
%    by N. Harish, K. Porwal, J. Valdman and S. K. Acharya (Date: 02/12/2024). 
%    The reader should consult that paper for more information. 
close all
levels=8;   % max. level=10 - 1048576 triangles
load('coordinates.dat');   load('elements.dat'); 
load('Dirichlet.dat');     load('Neumann.dat');
[n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
params.A=[1 0; 0 1]; params.p=[1,1]; params.delta=1; % problem parameters
 for level=1:levels
    fprintf('Level %d, ',level);   
    [coordinates,elements,Dirichlet,Neumann]=redrefine_vec(coordinates,elements,n2ed,ed2el,Dirichlet,Neumann);
    [n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
    nE=size(elements,1); % Number of elements
    nEd=size(ed2el,1); % Number of Edges
    fprintf('number of elements = %d, number of edges = %d \n',nE,nEd);
    Dbed= diag(n2ed(Dirichlet(:,1),Dirichlet(:,2)));  %Dirichlet boundary edges
    Nbed= diag(n2ed(Neumann(:,1),Neumann(:,2))); %Neumann boundary edges
    Redges=setdiff(1:nEd,Nbed); % removing Neumann edges from all edges
    tic
    [B,D,M,b]=StiffMassConv_PH(coordinates,elements,params);
    toc3=toc;
    fprintf('Computational time (in sec) for the function StiffMassConv_PH.m  is = %3.3f \n',toc3);
    tic
    [C,e11,v,R11]= Lambda_PH(coordinates,ed2el,intE,Dbed,Redges,led,ledTN);
    toc4=toc;
    fprintf('Computational time (in sec) for the function Lambda_PH.m  is = %3.3f \n',toc4);
    outputMatrix(level,1)=level;
    outputMatrix(level,2)=size(elements,1);
    outputMatrix(level,3)=nEd;
    outputMatrix(level,4)=toc3;
    outputMatrix(level,5)=toc4;
    fprintf('\n');
 end
 fprintf('Table 3: Run-time of the StiffMassConv_PH.m and Lambda_PH.m \n')
 print_matrix(outputMatrix);

  