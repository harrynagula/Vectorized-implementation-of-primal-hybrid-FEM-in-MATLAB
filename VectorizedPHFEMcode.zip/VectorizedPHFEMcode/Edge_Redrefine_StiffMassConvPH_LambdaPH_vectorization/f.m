function fv=f(z,params)
A=params.A;p=params.p;delta=params.delta;
x1=z(:,1); x2=z(:,2);  
fv=(A(2,2)*2*(x1-x1.^2))+(A(1,1)*2*(x2-x2.^2))-(A(1,2)*(1-2*x1).*(1-2*x2))-...
    (A(2,1)*(1-2*x1).*(1-2*x2))-(p(2)*(x1-x1.^2).*(1-2*x2))-...
    (p(1)*(1-2*x1).*(x2-x2.^2))+delta*(x1-x1.^2).*(x2-x2.^2);


