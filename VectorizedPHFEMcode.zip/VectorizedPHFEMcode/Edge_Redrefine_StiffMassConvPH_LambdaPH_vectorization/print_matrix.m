function print_matrix(matrix,form_f)
if nargin==1
   form_f=' %3.3f ';
end
form_d='  %d   ';

for i=1:size(matrix,1)    
    for j=1:size(matrix,2)
        if j >1
            fprintf(' & ')
        end
        if matrix(i,j)==0
            fprintf(' - ');
        else
            if matrix(i,j)==round(matrix(i,j),1)
                fprintf(strcat(form_d), matrix(i,j));
            else
                fprintf(strcat(form_f), matrix(i,j));
            end
        end        
    end
    fprintf('  \\\\ \n')    
end