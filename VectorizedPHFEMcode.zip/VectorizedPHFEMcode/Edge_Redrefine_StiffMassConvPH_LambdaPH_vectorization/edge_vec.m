function [nodes2element,nodes2edge,edge2element,intE,extE,led,ledTN]=edge_vec(elements,coordinates)
nE=size(elements,1);    %number of elements
nC=size(coordinates,1);    % number of nodes
I=elements(:);
J=reshape(elements(:,[2 3 1]), numel(elements), 1);
S=[1:nE,1:nE,1:nE]'; 
nodes2element=sparse(I, J, S, nC, nC);
[~,~,localE]=find(sparse(I, J, repmat([3,1,2],nE,1), nC, nC)); % position of edge in element
B=nodes2element+nodes2element';
[i,j]=find(triu(B));
nodes2edge=sparse(i,j,1:size(i,1),nC,nC);
nodes2edge=nodes2edge+nodes2edge';
nEd=size(i,1);   % number of edges
%% to generate element of edge 
[nodes1,nodes2,ielems]=find(nodes2element);      
nodes2elementSparsity=sparse(nodes1,nodes2,ones(size(nodes1,1),1),nC, nC);
nodes2edgesDirected=nodes2edge.*nodes2elementSparsity;
[~,~,iedges]=find(nodes2edgesDirected);  
data=[iedges ielems,nodes1,nodes2,localE];       % edge, element, node1, node2, position in element
dataSort=sortrows(data);                  
idxl=[true; diff(dataSort(:,1))>0];     
edge2element=zeros(nEd,4);
edge2element(:,1:3)=dataSort(idxl,[3 4 2]);   % first occurence of an edge
led=dataSort(idxl,5); ledTN=led;
IdxTN=find(idxl==0); 
edge2element(dataSort(IdxTN,1),4)=dataSort(IdxTN,2); % repetition of the edge
ledTN(dataSort(IdxTN,1),1)=dataSort(IdxTN,5); 
%% To produce the interior edges
intE=find(edge2element(:,4));
%% To produce the exterior edges
extE=find(edge2element(:,4)==0);
end

