 function [C,e11,v,R11]= Lambda_PH(coordinates,ed2el,intE,Dbed,Redges,led,ledTN)
nEd=size(ed2el,1); % number of edges
num_intE=size(intE,1); % number of interior edges
nDb=size(Dbed,1); % number of Dirichlet boundary edges
edges=ed2el(1:nEd,1:2);   % all edges 
%% Vectorization of matrix C
v=vecnorm((coordinates(edges(:,1),:)-coordinates(edges(:,2),:))')';  % length of edges
e11=ed2el(:,3); e12=nonzeros(ed2el(:,4));
i=find(led==1); j=find(led==2); k=find(led==3);
p=find(ledTN(intE)==1); q=find(ledTN(intE)==2); r=find(ledTN(intE)==3);
R1=[0, 1/2, 1/2]; R2= [1/2, 0,  1/2]; R3= [1/2, 1/2, 0];
R11(i,:)=repmat(R1,size(i));
R11(j,:)=repmat(R2,size(j));
R11(k,:)=repmat(R3,size(k));
R22(p,:)=repmat(R1,size(p));
R22(q,:)=repmat(R2,size(q));
R22(r,:)=repmat(R3,size(r));
I1=reshape([Dbed' intE';Dbed' intE';Dbed' intE'],3*(num_intE+nDb),1);
J1=reshape(((e11([Dbed' intE'])-ones(num_intE+nDb,1))*3 +[1 2 3])'...
        ,3*(num_intE+nDb),1);
S1=reshape(( v([Dbed' intE']).* R11([Dbed' intE'],:))',3*(num_intE+nDb),1);
I2=reshape([intE';intE';intE'],3*num_intE,1);
J2=reshape(((e12(:)-ones(num_intE,1))*3 +[1 2 3])',3*num_intE,1);
S2=reshape(( (-1)*v(intE).*(R22))',3*num_intE,1);
I=[I1;I2]; J=[J1;J2]; S=[S1;S2]; % appending vectors
C=sparse(I,J,S);
C=C(Redges,:);  % eliminate extra rows
end
