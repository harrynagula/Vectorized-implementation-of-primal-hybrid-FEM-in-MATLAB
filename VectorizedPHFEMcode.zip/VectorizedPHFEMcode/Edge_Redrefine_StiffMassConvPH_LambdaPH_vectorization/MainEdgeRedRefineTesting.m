%    MainEdgeRedRefineTesting.m is calculates the runtimes listed in 
%    Table 2 for the vectorized code of edge.m and redrefine.m.

%    Remark: This program is a supplement to the paper 
%    "Vectorized implementation of primal hybrid FEM in MATLAB" 
%    by N. Harish, K. Porwal, J. Valdman and S. K. Acharya (Date: 02/12/2024). 
%    The reader should consult that paper for more information. 
clearvars
close all
levels=8;       % max. level=11 - 16777216 triangles
load('coordinates.dat');   load('elements.dat'); 
load('Dirichlet.dat');     load('Neumann.dat');
[n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
 for level=1:levels
    fprintf('Level %d, ',level);   
    tic  
    [coordinates,elements,Dirichlet,Neumann]=redrefine_vec(coordinates,elements,n2ed,ed2el,Dirichlet,Neumann);
    toc1=toc;
    fprintf('number of elements = %d\n',size(elements,1));
    fprintf('Time (in sec) for redrefine_vec.m  is = %3.3f \n',toc1);       
    tic
    [n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
    toc2=toc;   
    fprintf('Time (in sec) for edge_vec.m  is = %3.3f, number of edges = %d \n',toc2, size(ed2el,1));
    outputMatrix(level,1)=level;
    outputMatrix(level,2)=size(elements,1);
    outputMatrix(level,3)=size(ed2el,1);   
    outputMatrix(level,4)=toc1;
    outputMatrix(level,5)=toc2;   
    fprintf('\n');
 end

 fprintf('Table 2: Run-time of the redrefine_vec.m and edge_vec.m \n')
 print_matrix(outputMatrix);


  