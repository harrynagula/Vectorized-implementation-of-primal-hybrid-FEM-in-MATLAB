function [L2e,Xe,herr]=PHerror(uh,Kh,Red2el,grad4e,elements,coordinates,h,v,params)   
nE=size(elements,1); % number of elements
P1=coordinates(elements(:,1),:); % collection of the first nodes of all triangle
P2=coordinates(elements(:,2),:); % collection of the second nodes of all triangle
P3=coordinates(elements(:,3),:); % collection of the third nodes of all triangle
e2=P3-P1; e3=P2-P1; % represents the edges of the elements in a mesh
area=(e3(:,1).*e2(:,2)-e3(:,2).*e2(:,1))/2; 
grad1=reshape(grad4e(1,:,:),2,nE); % gradient at first node
grad2=reshape(grad4e(2,:,:),2,nE); % gradient at second node
grad3=reshape(grad4e(3,:,:),2,nE); % gradient at third node
uh=reshape(uh,3,nE)';              
Xgrad=[grad1(1,:)' grad2(1,:)' grad3(1,:)']; 
Ygrad=[grad1(2,:)' grad2(2,:)' grad3(2,:)'];
uhx=sum(Xgrad.*uh,2); uhy=sum(Ygrad.*uh,2); 
[X,Y,xw]=TriGaussPoints(7,P1,P2,P3);
W=ue([X, Y],nE);
%% L2- error
D=[P1(:,1)' P2(:,1)' P3(:,1)';
   P1(:,2)' P2(:,2)' P3(:,2)';
   ones(1,nE) ones(1,nE) ones(1,nE)]';
S=(D([1 nE+1 2*nE+1],:)')\[X(:,1),Y(:,1),ones(length(xw(:,1)),1)]';
L2e=area'.*xw(:,3).*((W- (uh*S)').^2);
L2e=sqrt(sum(L2e,'all'));
%% X-norm
[W1, W2]=uxe([X, Y],nE);
err=(W1-uhx').^2+(W2-uhy').^2;
Xe=area'.*xw(:,3).*(err+ h^(-2)*(W- (uh*S)').^2);
Xe=sqrt(sum(Xe,'all'));
%% h-norm error
[KNM,KNF,KNL]=exactLambda(coordinates,Red2el,params);
herr=sqrt(h*((v/3)'*((KNF-Kh).^2+4*(KNM-Kh).^2+(KNL-Kh).^2)));
end