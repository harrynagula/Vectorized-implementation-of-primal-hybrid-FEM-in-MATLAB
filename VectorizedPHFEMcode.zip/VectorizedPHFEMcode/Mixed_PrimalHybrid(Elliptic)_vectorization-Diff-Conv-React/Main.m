%    Main solves the equation
%    -nabla.(A nabla u + u p)+ delta u = f       
%    Dirichlet BC is u=uD and Neumann BC is (A nabla u + u p).v = g 
%    take A=I, p=(1,1) and delta=1 
%    Therefore, Main assembles the vectorized stiffness, mass, convection, Lagrange  
%    matrix and also right-hand side. Then uses reduced linear system of equations 
%    to calculate a discrete solution of the above problem.
%    Volume force and boundary data are given as M-files <f.m>, <g.m>, <uD.m>.
%    Main loads the mesh data from data-files. The program reads 
%    the triangular elements from the files <elements.dat>, coordinates  
%    <coordinates.dat>, and boundary data <Dirichlet.dat>, <Neumann.dat>.

%    Remark: This program is a supplement to the paper 
%    "Vectorized implementation of primal hybrid FEM in MATLAB" 
%    by N. Harish, K. Porwal, J.Valdman and S. K. Acharya (Date: 02/12/2024). 
%    The reader should consult that paper for more information.   
format short
clc; clear all;
load('coordinates.dat');   load('elements.dat'); 
load('Dirichlet.dat');     load('Neumann.dat');
[n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
params.A=[1 0;0 1]; params.p=[1,1]; params.delta=1; % problem parameters
nt=4;
for level=1:nt
    fprintf('Level = %d\n',level); 
    tic  
    [coordinates,elements,Dirichlet,Neumann]=redrefine_vec(coordinates,elements,n2ed,ed2el,Dirichlet,Neumann);
    fprintf('run-time (in sec) for the function redrefine_vec.m  is = %3.3f\n',toc);
    tic
    [n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
    fprintf('run-time (in sec) for the function edge_vec.m  is = %3.3f\n',toc);
    h(level)=sqrt(det([1 1 1;coordinates(elements(1,:),:)'])*2); % space parameter
    grad4e = getGrad4e(coordinates,elements);
    nE=size(elements,1);  % Number of elements
    nEd=size(ed2el,1); % Number of Edges
    fprintf('number of elements = %d, number of edges = %d \n',nE,nEd);
    if (~isempty(Dirichlet))
        Dbed=n2ed(sub2ind(size(n2ed),Dirichlet(:,1),Dirichlet(:,2))); %Dirichlet boundary edges
    else
        Dbed=[];
    end
    if (~isempty(Neumann))
        Nbed=n2ed(sub2ind(size(n2ed),Neumann(:,1),Neumann(:,2))); %Neumann boundary edges
    else
        Nbed=[];
    end
    Redges=setdiff(1:nEd,Nbed); % removing Neumann edges from all edges
    L=length(Redges);  
    ndf=3*nE;            %degree of freedom       
    tic
    [B,D,M,b]=StiffMassConv_PH(coordinates,elements,params);
    fprintf('run-time (in sec) for the function StiffMassConv_PH.m  is = %3.3f\n',toc);
    tic
    [C,e11,v,R11]= Lambda_PH(coordinates,ed2el,intE,Dbed,Redges,led,ledTN);
    fprintf('run-time (in sec) for the function Lambda_PH.m  is = %3.3f\n',toc);
    %% Vectorization of Neumann BC
    LN=sparse(ndf,1);
    if (~isempty(Neumann))        
        nNb=size(Nbed,1); % number of Neumann boundary edges
        NP1=coordinates(Neumann(:,1),:); NP2=coordinates(Neumann(:,2),:); 
        Nmd=(NP1+NP2)/2; % mid-point of Neumann edges
        Nnorm=[NP2(:,2)-NP1(:,2) NP1(:,1)-NP2(:,1)]./vecnorm((NP1-NP2)')'; %normal to Neumann edge
        JN=reshape(((e11(Nbed)-ones(nNb,1))*3+[1 2 3])',3*nNb,1); 
        S=reshape(((diag(v(Nbed).*g(Nmd,params)*Nnorm')).*R11(Nbed,:))',3*nNb,1);
        LN=accumarray(JN,S,[ndf 1]); 
    end     
    %% Dirichlet boundary condition
    uhb1=sparse(L,1); 
    if (~isempty(Dirichlet))
        [ed,~]=find(Redges==Dbed);  % extract the linear indices of Dirichlet edge number 
        me=(coordinates(Dirichlet(:,2),:)+coordinates(Dirichlet(:,1),:))/2; % mid-point of Dirichlet edges
        uhb1(ed)=-v(Dbed).*uD(me);
    end
%%%%%%% Solving saddle point problem %%%%%% 
    tic
    Mvec=[ B + D + M         -C'
         -C          sparse(L,L)];
    Fvec=[b+LN; uhb1];   
    Wvec=Mvec\Fvec; 
    uh=Wvec(1:ndf);
    Kh=Wvec(1+ndf:length(Wvec));
    u=ue(coordinates(elements',:)); % exact solution
    [K]=exactLambda(coordinates,ed2el(Redges,1:2),params);
    fprintf('run-time (in sec) for the linear solver is = %3.3f\n',toc);
    tic 
    [L2e(level),Xe(level),herr(level)]=PHerror(uh,Kh,ed2el(Redges,1:2),grad4e,elements,coordinates,h(level),v(Redges),params);  
    fprintf('run-time (in sec) for the function PHerror.m is = %3.3f\n',toc);
    fprintf('\n');
end
%% order of convergence 
for j=1:level-1
    ocX(j)=log(Xe(j)/Xe(j+1))/log(h(j)/h(j+1));
    ocL2(j)=log(L2e(j)/L2e(j+1))/log(h(j)/h(j+1));
    och(j)=log(herr(j)/herr(j+1))/log(h(j)/h(j+1));  
end
fprintf('\n order of convergences w.r.t h \n in  level  ||u-uh||_X  X-norm  ||u-uh||_L2 L2-norm  ||K-Kh||_h h-norm \n');
disp(['    ' num2str(1,'%.4f') '    ',num2str(Xe(1),'%.4f'),...
    '      -       ',num2str(L2e(1),'%.4f'),'      -       ',num2str(herr(1),'%.4f'),'      -  '])
disp([(2:level)', Xe(2:end)', ocX', L2e(2:end)', ocL2',herr(2:end)', och']);