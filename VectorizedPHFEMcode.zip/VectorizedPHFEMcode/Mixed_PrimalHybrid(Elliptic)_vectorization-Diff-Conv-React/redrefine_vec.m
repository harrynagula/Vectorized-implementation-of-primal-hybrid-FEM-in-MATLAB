function [coordinates,elements,Dirichlet,Neumann]=...
    redrefine_vec(coordinates,elements,n2ed,ed2el,Dirichlet,Neumann)
nE=size(elements,1); % number of elements
nEd=size(ed2el,1); % number of edges
%% Coordinates
Marker=(size(coordinates,1)+1:size(coordinates,1)+nEd)';
coordinates=[coordinates;(coordinates(ed2el(:,1),:)+coordinates(ed2el(:,2),:))/2];
%% Elements
M1= Marker(n2ed(sub2ind(size(n2ed),elements(:,2),elements(:,3))));
M2= Marker(n2ed(sub2ind(size(n2ed),elements(:,3),elements(:,1))));
M3= Marker(n2ed(sub2ind(size(n2ed),elements(:,1),elements(:,2))));
elements(reshape(nE+1:4*nE,3,nE)',:) = [elements(:),[M3;M1;M2],[M2;M3;M1]];
elements((1:nE),:)=[M1 M2 M3];
%% Dirichlet and Neumann boundary
if (~isempty(Dirichlet)), Dirichlet=refineEdges(Dirichlet); end
if (~isempty(Neumann)), Neumann=refineEdges(Neumann); end
%% subfunction refineEdges
    function ed2n=refineEdges(ed2n)
        nEd=size(ed2n,1); % number of edges
        M=Marker(n2ed(sub2ind(size(n2ed),ed2n(:,1),ed2n(:,2))));
        ed2n(nEd+1:2*nEd,:)=[M ed2n(1:nEd,2)];
        ed2n(1:nEd,2)=M;
    end
end