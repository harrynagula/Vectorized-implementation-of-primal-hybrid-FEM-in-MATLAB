function [uxv,uyv]=uxe(z,nE)
if nargin==1
    x1=z(:,1); x2=z(:,2);
    uxv=(1-2*x1).*(x2-x2.^2); 
    uyv=(1-2*x2).*(x1-x1.^2); 
else   % This 'else' statement is used to compute the derivatives of the exact solution at Gaussian points
    x1=z(:,1:nE); x2=z(:,nE+1:2*nE); 
    uxv=(1-2*x1).*(x2-x2.^2);
    uyv=(1-2*x2).*(x1-x1.^2);
end

