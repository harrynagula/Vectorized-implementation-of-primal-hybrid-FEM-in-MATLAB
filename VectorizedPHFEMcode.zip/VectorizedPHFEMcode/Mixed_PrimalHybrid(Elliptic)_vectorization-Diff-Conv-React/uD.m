function uv=uD(z)
uv=ue(z);