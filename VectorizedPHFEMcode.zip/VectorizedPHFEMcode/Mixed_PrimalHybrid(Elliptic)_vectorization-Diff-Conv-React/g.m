function gv=g(z,params)
A=params.A; p=params.p;
[Nuxv,Nuyv]=uxe(z);
gv=([A(1,1)*Nuxv+A(1,2)*Nuyv,A(2,1)*Nuxv+A(2,2)*Nuyv]+[p(1)*ue(z),p(2)*ue(z)]);
