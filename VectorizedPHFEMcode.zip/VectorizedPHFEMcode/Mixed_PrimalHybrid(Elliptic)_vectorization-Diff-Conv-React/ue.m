function uv=ue(z,nE)
if nargin==1
    x1=z(:,1); x2=z(:,2);
    uv=(x1-x1.^2).*(x2-x2.^2); 
else  % This 'else' statement is used for computing the exact solution at Gaussian points
    x1=z(:,1:nE); x2=z(:,nE+1:2*nE);  % Gaussian points
    uv=(x1-x1.^2).*(x2-x2.^2);   
end


