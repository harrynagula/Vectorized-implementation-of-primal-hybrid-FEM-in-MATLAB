function [B,D,M,b]=StiffMassConv_PH(coordinates,elements,params)
A=params.A;p=params.p;delta=params.delta;
nE=size(elements,1);  % number of elements
%% Vectorization of B matrix
P1=coordinates(elements(:,1),:); % collection of the first nodes of all triangles
P2=coordinates(elements(:,2),:); % collection of the second nodes of all triangles
P3=coordinates(elements(:,3),:); % collection of the third nodes of all triangle
e1=P3-P2; e2=P3-P1; e3=P2-P1;  % represents the edges of the elements in a mesh
mp23=(P2+P3)/2;  mp13=(P1+P3)/2;   mp12=(P1+P2)/2; % mipoints of the edges
area=(e2(:,2).*e3(:,1)-e2(:,1).*e3(:,2))/2; % Area
GI=reshape([1:3*nE; 1:3*nE; 1:3*nE],9,nE);  % 3*nE =Number of nodes
I3=reshape(GI([1 4 7 2 5 8 3 6 9],:),9*nE,1); J3=reshape(GI,9*nE,1);
G1=[-e1(:,2),e1(:,1)]./(2*area); G2=[e2(:,2),-e2(:,1)]./(2*area); G3=[-e3(:,2),e3(:,1)]./(2*area);
BT=[[dot(G1*A,G1,2),dot(G1*A,G2,2),dot(G1*A,G3,2),dot(G2*A,G1,2),dot(G2*A,G2,2),...
    dot(G2*A,G3,2),dot(G3*A,G1,2),dot(G3*A,G2,2),dot(G3*A,G3,2)].*area]';
B=sparse(I3,J3,BT,3*nE,3*nE);
%% Vectorization of mass matrix (M)
MT=reshape(delta*(area/12)'.*[2;1;1;1;2;1;1;1;2],9*nE,1);
M=sparse(I3,J3,MT,3*nE,3*nE);
%% Vectorization of D matrix 
h1=(-p(1)*e1(:,2)+p(2)*e1(:,1))'/6;
h2=(p(1)*e2(:,2)-p(2)*e2(:,1))'/6;
h3=(-p(1)*e3(:,2)+p(2)*e3(:,1))'/6;
DT=[h1; h2; h3; h1; h2; h3; h1; h2; h3];
D=sparse(I3,J3,DT,3*nE,3*nE); 
%% Vectorization of load vector b
f1=f(mp13,params)/2 +f(mp12,params)/2;
f2=f(mp23,params)/2+f(mp12,params)/2;
f3=f(mp13,params)/2+f(mp23,params)/2;
fT=(area.*[f1 f2 f3])/3;
b=accumarray(reshape(1:3*nE,3*nE,1), reshape(fT',3*nE,1) ,[3*nE 1]);
end
