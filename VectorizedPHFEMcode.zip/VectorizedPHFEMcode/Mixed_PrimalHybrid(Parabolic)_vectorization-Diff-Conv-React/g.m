function gv=g(z,n,dt,params)
A=params.A; p=params.p;
[Nuxv,Nuyv]=uxe(z,repmat(n*dt,size(z,1),1));
gv=([A(1,1)*Nuxv+A(1,2)*Nuyv,A(2,1)*Nuxv+A(2,2)*Nuyv]+[p(1)*ue(z,repmat(n*dt,size(z,1),1)),p(2)*ue(z,repmat(n*dt,size(z,1),1))]);