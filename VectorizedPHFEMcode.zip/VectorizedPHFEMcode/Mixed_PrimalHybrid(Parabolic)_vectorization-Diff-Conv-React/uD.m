function uv=uD(z,t)
uv= ue(z,t);