function h=show_nodal_scalar_discontinuous_frame(nodalValue,elements,coordinates,nodalDisplacement)
switch nargin 
    case 3
        nodalDisplacement=0*coordinates;
    case {0, 1, 2}
        fprintf('missing parameters')
end

X=coordinates(:,1)+nodalDisplacement(:,1);
Y=coordinates(:,2)+nodalDisplacement(:,2);

h=fill3(X(elements)',Y(elements)',squeeze(nodalValue)',squeeze(nodalValue)','FaceColor','interp','Linewidth',0.1,'EdgeColor','k');
%set(gcf,'renderer','zbuffer');