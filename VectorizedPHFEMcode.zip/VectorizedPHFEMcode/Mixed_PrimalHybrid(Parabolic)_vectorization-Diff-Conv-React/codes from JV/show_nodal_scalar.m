function show_nodal_scalar(nodalValue,elements,coordinates,nodalDisplacement)
if nargin==3
    h=show_nodal_scalar_frame(nodalValue,elements,coordinates);
elseif nargin==4
    h=show_nodal_scalar_frame(nodalValue,elements,coordinates,nodalDisplacement);
end
set(h,'edgecolor','none')    
