function h=highlight_edges(edges2nodes,nodes2coord,edges2color)
X=[nodes2coord(edges2nodes(:,1),1) nodes2coord(edges2nodes(:,2),1)];
Y=[nodes2coord(edges2nodes(:,1),2) nodes2coord(edges2nodes(:,2),2)];

if size(nodes2coord,2)==3
    Z=[nodes2coord(edges2nodes(:,1),3) nodes2coord(edges2nodes(:,2),3)];
else
    Z=0*X;
end

if nargin<3
   C=zeros(size(X)); edgetype='y';
else
   C=kron(edges2color,[1 1]); edgetype='flat';
end

%plot3(X',Y',Z','LineWidth', 10)
%patch(X',Y',Z',C','LineWidth', 10,'EdgeColor','interp','FaceColor','none')
%h=patch(X',Y',C',C','LineWidth', 1, 'EdgeColor',edgetype)
h=patch(X',Y',C',C','LineWidth', 1,'EdgeColor',edgetype);
%h=fill3(X',Y',C',C');

end



