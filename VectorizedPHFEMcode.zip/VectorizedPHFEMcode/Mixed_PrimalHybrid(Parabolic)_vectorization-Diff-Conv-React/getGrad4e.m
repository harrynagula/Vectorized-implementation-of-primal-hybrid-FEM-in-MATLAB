function grad4e = getGrad4e(coordinates,elements)
nE=size(elements,1); % number of elements
P1=coordinates(elements(:,1),:);  % collection of the first nodes of all triangles
P2=coordinates(elements(:,2),:);  % collection of the second nodes of all triangles
P3=coordinates(elements(:,3),:);  % collection of the third nodes of all triangles
e1=P3-P2; e2=P3-P1; e3=P2-P1;   % represents the edges of the elements in a mesh
area=(e2(:,2).*e3(:,1)-e2(:,1).*e3(:,2))/2; % area2= 2*|T|
g11=-e1(:,2)./(2*area); g12=e1(:,1)./(2*area);
g21=e2(:,2)./(2*area); g22=-e2(:,1)./(2*area);
g31=-e3(:,2)./(2*area); g32=e3(:,1)./(2*area);
G=[g11, g12; g21, g22; g31, g32];
grad4e(1,:,:)=G(1:nE,:)'; grad4e(2,:,:)=G(nE+1:2*nE,:)'; 
grad4e(3,:,:)=G(2*nE+1:3*nE,:)';




