function uv=ue(z,t,nE)
if nargin==2
    x1=z(:,1); x2=z(:,2);
    uv=t.*(x1-x1.^2).*(x2-x2.^2); % u=t*x1*(1-x1)*x2*(1-x2)
else  % This 'else' statement is used for computing the exact solution at Gaussian points.
    x1=z(:,1:nE);x2=z(:,nE+1:2*nE);
    uv=t.*(x1-x1.^2).*(x2-x2.^2);
end
