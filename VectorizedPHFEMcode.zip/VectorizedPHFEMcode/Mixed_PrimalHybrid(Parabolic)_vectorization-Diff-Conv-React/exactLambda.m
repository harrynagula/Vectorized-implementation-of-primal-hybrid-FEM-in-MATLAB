function [K,KNF,KNL]=exactLambda(coordinates,Red2el,n,params)
A=params.A; p=params.p;
P1=coordinates(Red2el(:,1),:); P2=coordinates(Red2el(:,2),:);
Nm=[P2(:,2)-P1(:,2) P1(:,1)-P2(:,1)]./(vecnorm((P1-P2)'))'; 
md=(P1+P2)/2;
uexc=ue(md,n); [uxv,uyv]=uxe(md,n);
K=((A(1,1)*uxv+A(1,2)*uyv+p(1)*uexc).*Nm(:,1)+(A(2,1)*uxv+A(2,2)*uyv+p(2)*uexc).*Nm(:,2));
%%
if nargout>1
    uexcF=ue(P1,n); [uxvF,uyvF]=uxe(P1,n);
    KNF=((A(1,1)*uxvF+A(1,2)*uyvF+p(1)*uexcF).*Nm(:,1)+(A(2,1)*uxvF+A(2,2)*uyvF+p(2)*uexcF).*Nm(:,2));
    %%
    uexcL=ue(P2,n); [uxvL,uyvL]=uxe(P2,n);
    KNL=((A(1,1)*uxvL+A(1,2)*uyvL+p(1)*uexcL).*Nm(:,1)+(A(2,1)*uxvL+A(2,2)*uyvL+p(2)*uexcL).*Nm(:,2));
end
end
