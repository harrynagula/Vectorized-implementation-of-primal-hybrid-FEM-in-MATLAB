%  ParabolicMain solves the second order parabolic problem 
%        d/dt u - div(A grad(u)+u*p)+ delta * u =  f   in Omega
%                                             u = u_D  on the Dirichlet boundary
%                             (A grad(u)+u*p).n = g    on the Neumann boundary 
%                                            u0 = 0    initial condition
%  Crank-Nicolson (CN) or backward Euler (bE) finite difference schemes are applied. 
%  CN is the second order accurate method in time. h^r+k^2 i.e., 
%  for space direction h^2 (r=2) and for time direction it is k^2 
%  bE is the first order accurate method in time. h^(r-1)+k i.e.,
%  for space direction h^1 (r=2) and for time direction it is k^1
%  ParabolicMain uses reduced linear system of equations to calculate 
%  a discrete solution of the above problem.
%  Volume force and boundary data are given as M-files <f.m>, <g.m>, <uD.m>.
% 
%  ParabolicMain loads the mesh data from data-files. The program reads 
%  the triangular elements from the files <elements.dat>, coordinates  
%  <coordinates.dat>, and boundary data <Dirichlet.dat>, <Neumann.dat>. 
%
%  Remark: This program is a supplement to the paper 
%  "Vectorized implementation of primal hybrid FEM in MATLAB" 
%  by N. Harish, K. Porwal, J. Valdman and S. K. Acharya (Date: 02/12/2024). 
%  The reader should consult that paper for more information. 

clc; clear all;
add_paths;
visualize=1;
method=1;     % 1 - Crank Nicolson, 2- Backward Euler
params.A=[1 0;0 1]; params.p=[1,1]; params.delta=1; % problem parameters
delta=params.delta;
nt=4;         % number of uniform mesh refinements
load('coordinates.dat');   load('elements.dat'); 
load('Dirichlet.dat');     load('Neumann.dat');
[n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
for level=1:nt
    fprintf('Level = %d\n',level);  
    tic
    [coordinates,elements,Dirichlet,Neumann]=redrefine_vec(coordinates,elements,n2ed,ed2el,Dirichlet,Neumann);
    toc1=toc;
    nE=size(elements,1);   % number of elements
    ndf=3*nE;   % degrees of freedom
    h(level)=sqrt(det([1 1 1;coordinates(elements(1,:),:)'])*2); % space parameter
    k(level)=h(level);   % time step - mesh size relation    
    if visualize && (nt-level<=1)
      figure; show_mesh(elements,coordinates);
      if (~isempty(Dirichlet))
         hold on
         ln=unique(coordinates(Neumann(:),:),'rows');
         line(ln(:,1),ln(:,2),'Color','red','LineWidth',1.0);
         hold off
      end
    end   
    tic
    [n2el,n2ed,ed2el,intE,extE,led,ledTN]=edge_vec(elements,coordinates);
    nEd=size(ed2el,1); % Number of Edges
    toc2=toc;
    fprintf('number of elements = %d, number of edges = %d, h = %f \n',nE, nEd,h(level));
    fprintf('Computational time(in sec) for the function redrefine_vec.m  is = %d\n',toc1);
    fprintf('Computational time(in sec) for the function redrefine_vec.m  is = %d\n',toc1);
    fprintf('Computational time(in sec) for the function edge_vec.m  is = %d\n',toc2);
    grad4e = getGrad4e(coordinates,elements);
    nEd=size(ed2el,1); % Number of Edges
    if ~isempty(Dirichlet)
        Dbed=n2ed(sub2ind(size(n2ed),Dirichlet(:,1),Dirichlet(:,2))); %Dirichlet boundary edges
    else
        Dbed=[];
    end
    if (~isempty(Neumann))
        Nbed=n2ed(sub2ind(size(n2ed),Neumann(:,1),Neumann(:,2))); %Neumann boundary edges
    else
        Nbed=[];
    end
    Redges=setdiff(1:nEd,Nbed); 
    L=length(Redges); 
    tic
    [C,e11,v,R11]= Lambda_PH(coordinates,ed2el,intE,Dbed,Redges,led,ledTN);
    fprintf('Computational time(in sec) for the function Lambda_PH.m  is = %d\n',toc);
    T = 1;  % final time
    N = round(T/k(level));   % number of time steps
    k(level)=T/N;
    U = sparse(ndf+L,N);
    %% Initial Condition
    U(:,1) = zeros(ndf+L,1); %uh(.,0)=0
    tic
    [B,D,M]=StiffConvMass_PH(elements,coordinates,params);
    fprintf('Computational time(in sec) for the function StiffMassConv_PH.m  is = %d\n',toc);
    %% time steps 
    if ~isempty(Dirichlet)
        [ed,~]=find(Redges==Dbed); % extract the linear indices of Dirichlet edge number 
        me=(coordinates(Dirichlet(:,2),:)+coordinates(Dirichlet(:,1),:))/2; % mid-point of Dirichlet edges
    end
    if method==1 % Crank Nicolson 
        M2vec=[ (1-(k(level)/2)*delta)*M-(k(level)/2)*B - (k(level)/2)*D       (k(level)/2)*C'
                         (1/2)*C                                            sparse(L,L)];
        M1vec=[ (1+(k(level)/2)*delta)*M+(k(level)/2)*B + (k(level)/2)*D      -(k(level)/2)*C'
                        -(1/2)*C                                            sparse(L,L)];     
    else % Backward Euler
        M2vec=[     M                     sparse(3*nE,L)
                      sparse(L,3*nE)             sparse(L,L)];
        M1vec=[ (1+(k(level))*delta)*M+(k(level))*B+ (k(level))*D      -(k(level))*C'
                         -(1)*C                          sparse(L,L)];
    end
    stepsToVisualize=unique(ceil((1:4)*N./4));  % n-1 belongs to this set for visualization
    for n = 2:N+1         
        fprintf('time step: %d of %d ',n-1,N);
         uhb1=sparse(L,1);  if ~isempty(Dirichlet) uhb1(ed)=-v(Dbed).*uD(me,(n-1)*k(level));  end
         [b1,LN1] = load_t(coordinates,elements,Neumann,Nbed,n-1,k(level),e11,v,R11,params);
         F1=[(k(level)*(b1+LN1)) ;  uhb1]; 
         if method==1   % Crank Nicolson 
             fprintf('(Crank Nicolson) \n');
             uhb2=sparse(L,1);  if ~isempty(Dirichlet) uhb2(ed)=-v(Dbed).*uD(me,n*k(level)); end
             [b2,LN2] = load_t(coordinates,elements,Neumann,Nbed,n,k(level),e11,v,R11,params);
             F2=[(k(level)*(b2+LN2)) ; uhb2]; 
             % previous timestep 
             Fvec = ((F1+F2)/2) + M2vec* U(:,n-1);      
         else  % Backward Euler
             fprintf('(backward Euler) \n');
             % previous timestep            
             Fvec = F1 + M2vec* U(:,n-1);  
         end
        Wvec=M1vec\Fvec;  % linear solver
        U(:,n)=Wvec;
        
        counterVisualize=1;
        str1=strcat('level=',num2str(level));
        str2=strcat('(h=',num2str(h(level),'%2.4f'),'),');
        str3=strcat('time step=',num2str(n-1),' of');
        str4=strcat(num2str(N));
        str5=strcat('(t=',num2str((n-1)*k(level)),')');
        %if visualize && (level==nt) && (mod(n-1,round(N/4))==0) % 4 pictures are visualized
        if visualize && (level==nt) && (ismember(n-1,stepsToVisualize)) % pictures to visualize
            fprintf('visualize \n')
            [R,~,V]=find(n2ed);     % getting edges nodes
            [~,indV]=sort(V);       % V(indV) is now sorted list of numbers of edges
            RIndV=R(indV); 
            uNodal=ue(coordinates,n*k(level));
            uh=Wvec(1:ndf); 
            %uhMidpoint=uh(1:3:end);
            fig=figure; 
            subplot(1,2,1); show_nodal_scalar(uNodal,elements,coordinates); axis tight; title('Exact solution');
            subplot(1,2,2); show_nodal_scalar_discontinuous([uh(1:3:end) uh(2:3:end) uh(3:3:end)],elements,coordinates); axis tight;
            title('Approximate solution');            
            sgtitle([str1,' ',str2,' ',str3,' ',str4,' ',str5]);
            figsExact(counterVisualize)=fig.Number; counterVisualize=counterVisualize+1;           
        end        
        if visualize && (ismember(n-1,stepsToVisualize(end))) % pictures to visualize
            [R,~,V]=find(n2ed);     % getting edges nodes
            [~,indV]=sort(V);       % V(indV) is now sorted list of numbers of edges
            RIndV=R(indV); 
            ed2n=[RIndV(1:2:end) RIndV(2:2:end)]; % edges to nodes (needed for visualization of Lagrange multipliers)  
            uNodal=ue(coordinates,n*k(level));
            Kh=Wvec(1+ndf:length(Wvec));
            K=exactLambda(coordinates,ed2el(Redges,1:2),n*k(level),params);        
            figure; 
            subplot(1,2,1); highlight_edges(ed2n(Redges,:),coordinates,K); axis tight; axis square; colorbar('Location','westoutside');
            set(gca,'XAxisLocation','bottom','YAxisLocation','right'); title('Exact Lagrange multiplier');
            subplot(1,2,2); highlight_edges(ed2n(Redges,:),coordinates,Kh); axis tight; axis square; colorbar('Location','westoutside');
            set(gca,'XAxisLocation','bottom','YAxisLocation','right'); title('Approximate Lagrange multiplier');
            sgtitle([str1,' ',str2,' ',str3,' ',str4,' ',str5  ]);
        end
    end
    fprintf('\n')
    uh=Wvec(1:ndf);  
    Kh=Wvec(1+ndf:length(Wvec));
    u=ue(coordinates(elements',:),n*k(level)); % exact solution
    K=exactLambda(coordinates,ed2el(Redges,1:2),n*k(level),params); 
    [L2e(level),Xe(level),herr(level)]=PHerror(uh,Kh,ed2el(Redges,1:2),grad4e,elements,coordinates,v(Redges),h(level),n*k(level),params); 

if visualize %% plots to see k, k_h and |k-k_h|
    figure(6+nt+level); 
    subplot(1,3,1); highlight_edges(ed2el(Redges,:),coordinates,K); axis tight; axis square; colorbar('Location','westoutside');title(['\kappa ']);
    subplot(1,3,2); highlight_edges(ed2el(Redges,:),coordinates,Kh); axis tight; axis square; colorbar('Location','westoutside'); title(['\kappa_h ']);
    subplot(1,3,3); highlight_edges(ed2el(Redges,:),coordinates,abs(K-Kh)); axis tight; axis square; colorbar('Location','westoutside'); title(['|\kappa-\kappa_h|']);
    sgtitle([str1,' ',str2,' ',str3,' ',str4,' ',str5]);
end
end 
 for j=1:level-1
    ocL2(j)=log(L2e(j)/L2e(j+1))/log(h(j)/h(j+1));
    ocX(j)=log(Xe(j)/Xe(j+1))/log(h(j)/h(j+1));
    och(j)=log(herr(j)/herr(j+1))/log(h(j)/h(j+1));
 end
fprintf('\n order of convergences w.r.t h \n in level   ||u-uh||_X  X-norm  ||u-uh||_L2 L2-norm  ||K-Kh||_h h-norm \n');
disp(['    ' num2str(1, '%.4f') '    ',num2str(Xe(1),'%.4f'),...
    '      -       ',num2str(L2e(1),'%.4f'),'      -       ',num2str(herr(1),'%.4f'),'     -       '])
disp([(2:level)', Xe(2:end)', ocX', L2e(2:end)', ocL2', herr(2:end)', och']);

if visualize  % postprocessing figures
   for i=1:numel(figsExact)
       figure(figsExact(i));
       subplot(1,2,1); axis([0 1 0 1 0 0.07]); grid on;
       subplot(1,2,2); axis([0 1 0 1 0 0.07]); grid on;
       %ax=gca;      
   end
end


