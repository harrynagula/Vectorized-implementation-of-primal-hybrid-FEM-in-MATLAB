function [b,LN] = load_t(coordinates,elements,Neumann,Nbed,n,k,e11,v,R11,params) 
nE=size(elements,1);    % number of elements
ndf=3*nE;     % degree of freedom
%% Vectorization of load vector b
P1=coordinates(elements(:,1),:);
P2=coordinates(elements(:,2),:); e3=P2-P1;
P3=coordinates(elements(:,3),:); e2=P3-P1;
area=(e3(:,1).*e2(:,2)-e3(:,2).*e2(:,1))/2;  %Area |T|
mp23=(P2+P3)/2; mp13=(P1+P3)/2; mp12=(P1+P2)/2;
f1=(f(mp13,n*k,params)/2 + f(mp12,n*k,params)/2);
f2=(f(mp23,n*k,params)/2 + f(mp12,n*k,params)/2);
f3=(f(mp13,n*k,params)/2 + f(mp23,n*k,params)/2);
fA=(area.*[f1 f2 f3])/3;
b=accumarray(reshape(1:ndf,ndf,1), reshape(fA',ndf,1), [ndf 1]);
%% Vectorization of Neumann boundary condition
LN=sparse(ndf,1);
if (~isempty(Neumann))
    nNb=size(Nbed,1); % number of Neumann edges
    NP1=coordinates(Neumann(:,1),:); NP2=coordinates(Neumann(:,2),:);
    Nmd=(NP1+NP2)/2; % mid-point of Neumann edges
    Nnorm=[NP2(:,2)-NP1(:,2) NP1(:,1)-NP2(:,1)]./v(Nbed) ;  %normal to Neumann edge 
    JN=reshape(((e11(Nbed)-ones(nNb,1))*3+[1 2 3])',3*nNb,1);    
    S=reshape(((diag(v(Nbed).*g(Nmd,n,k,params)*Nnorm')).*R11(Nbed,:))',3*nNb,1);
    LN=accumarray(JN,S,[ndf 1]);
end
end